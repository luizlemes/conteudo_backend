<?php
    require_once "consultar_por_id.php";
    require_once "../template/cabecalho.php";
    require_once "../template/menu.php";



?>

<div class="container">
    <br><h1>Cadastro de pedidos</h1>
    <hr>

    <form action="<?php echo isset($pedido) ? "atualizar.php" : "inserir.php";?>" method="post" enctype="multipart/form-cliente">

        <input type="hidden" name="idpedido" value="<?php echo $pedido->idpedido ?? "" ;?>"><br>

        <label class="form-label">Cliente</label><br>
        <input class="form-control" type="text" name="cliente" value="<?php echo $pedido->cliente ?? "" ;?>"><br>
        
        <label class="form-label">Data</label><br>
        <input class="form-control" type="text" name="data" value="<?php echo $pedido->data ?? "" ;?>"><br>

        <label class="form-label">Status</label><br>
        <input class="form-control" type="text" name="status" value="<?php echo $pedido->status ?? "";?>"><br>

        <label class="form-label">Total</label><br>
        <input class="form-control" type="text" name="total" value="<?php echo $pedido->data ?? "" ;?>"><br>

        <button class="btn- btn-dark" type="submit">Inserir</button>
        
    </form>
    </div>
    <?php require_once "../template/rodape.php";?>