<ul class="nav nav-underline" style="margin:30px 100px 10px;">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="http://localhost/3infob/conteudo_backend/job/pedidooo/site/index.php?assunto=A%20caminho"><h5>Pagina Inicial</h5></a><br>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="../pedido/formulario.php"><h5>Inserir pedidos</h5></a><br>
  </li>
  <li class="nav-item">
  <a class="nav-link" href="../pedido/index.php"><h5>Gerenciamento de pedido</h5></a><br>
  </li>
</ul>