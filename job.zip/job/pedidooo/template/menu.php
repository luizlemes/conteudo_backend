<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <ul class="nav nav-underline" style="margin:10px  120px 0px;">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="../site/index.php"><h5>Pagina Inicial</h5></a><br>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="../pedido/formulario.php"><h5>Inserir pedidos</h5></a><br>
  </li>
  <li class="nav-item">
  <a class="nav-link" href="../pedido/index.php"><h5>Gerenciamento de pedido</h5></a><br>
  </li>
  </ul>
</nav>
<br>