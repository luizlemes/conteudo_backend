<ul></ul><ul></ul>
    <!-- Rodapé-->
    <footer class="bg-dark p-3 text-white text-center">
          Site de pedidos<br>Feito em 2023 por Luiz Lemes<!--: <br> luiz.lemes@alunos.ifsuelminas.edu.br-->
    </footer>
    <!-- final Rodapé-->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="" >
      let table = new DataTable('#tabela_dados');
    </script>
  </body>
</html>